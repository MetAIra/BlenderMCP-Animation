# シーン系スクリプトの共通ヘルパー（各 sc_*.py の冒頭で exec される）
# 呼び出し側 globals: SKILL, ROOT(プロジェクトルート), PLAN(dict), PARAMS(そのステップの設定)
# 座標: Z 上・メートル。キャラ/パーツの「正面」は -Y（yaw=180 で +Y を向く）
import bpy, math, re
import numpy as np
from mathutils import Vector, Matrix, Quaternion, Euler
from mathutils.bvhtree import BVHTree

O = bpy.data.objects
SC = bpy.context.scene
PLAN = globals().get("PLAN", {}) or {}
PARAMS = globals().get("PARAMS", {}) or {}
X, Y, Z = Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))

def prm(key, default=None):
    return PARAMS.get(key, default)

def rpath(p):
    """プロジェクトルート相対パス → 絶対パス"""
    import os
    return p if (":" in p[:3] or p.startswith("\\")) else os.path.join(ROOT, p.replace("/", "\\"))

def ensure_col(name, parent=None):
    c = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    par = parent or SC.collection
    if c.name not in [x.name for x in par.children]: par.children.link(c)
    return c

def to_col(ob, col):
    for c in list(ob.users_collection): c.objects.unlink(ob)
    col.objects.link(ob)

# ---------- 地面 ----------
_BVH = {}
def ground(x, y, name="Terrain"):
    ob = O.get(name)
    if ob is None: return 0.0
    if name not in _BVH:
        _BVH[name] = BVHTree.FromObject(ob, bpy.context.evaluated_depsgraph_get())
    hit = _BVH[name].ray_cast(Vector((x, y, 500)), Vector((0, 0, -1)))
    return hit[0].z if hit[0] else 0.0

def bbox_world(ob):
    bpy.context.view_layer.update()
    pts = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    mn = Vector([min(p[i] for p in pts) for i in range(3)]); mx = Vector([max(p[i] for p in pts) for i in range(3)])
    return mn, mx

def top_point(ob, strip=0.25):
    """物体の「上面」: 中心付近の帯（幅の strip 倍）を上からレイで調べ、最も高い点（鳥居の笠木・灯籠の宝珠など）"""
    mn, mx = bbox_world(ob)
    if ob.type != 'MESH' or ob.instance_type == 'COLLECTION':
        return Vector(((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, mx.z))
    bvh = BVHTree.FromObject(ob, bpy.context.evaluated_depsgraph_get())
    cx, cy = (mn.x + mx.x) / 2, (mn.y + mx.y) / 2; wx, wy = (mx.x - mn.x) * strip / 2, (mx.y - mn.y) / 2
    best = None
    for i in range(9):
        for j in range(41):
            px = cx - wx + 2 * wx * i / 8; py = cy - wy + 2 * wy * j / 40
            h = bvh.ray_cast(Vector((px, py, mx.z + 10)), Vector((0, 0, -1)))
            if h[0] is not None:
                d = abs(px - cx) + 0.2 * abs(py - cy)
                if best is None or h[0].z > best[0].z + 1e-3 or (abs(h[0].z - best[0].z) <= 1e-3 and d < best[1]):
                    best = (h[0].copy(), d)
    return best[0] if best else Vector((cx, cy, mx.z))

# ---------- 位置指定（spec）の解決 ----------
# spec の書き方:
#   [x, y, z]        そのまま
#   [x, y]           地面の高さを自動
#   "name"           オブジェクトの原点 / "name:top" 上面 / "name:center" bbox 中心 / "name:front" 正面(-Y側)の地面
#   "char" / "char1" キャラクター（0 番 / 1 番）の現在位置（frame 指定時はそのフレーム）
#   "sun"            太陽の方向（向き指定用）
#   上記 + "+[dx,dy,dz]"  オフセット
_OFF = re.compile(r"^(.*?)\s*\+\s*\[([^\]]*)\]\s*$")
def resolve(spec, frame=None):
    if spec is None: return None
    if isinstance(spec, (list, tuple)):
        if len(spec) == 2: return Vector((spec[0], spec[1], ground(spec[0], spec[1])))
        return Vector(spec)
    if isinstance(spec, dict):
        base = resolve(spec.get("at"), frame); return base + Vector(spec.get("offset", (0, 0, 0)))
    s = str(spec).strip(); off = Vector((0, 0, 0))
    m = _OFF.match(s)
    if m:
        s = m.group(1).strip(); off = Vector([float(v) for v in m.group(2).split(",")])
    if s.startswith("char"):
        idx = int(s[4:] or 0); arm = O[SC["scene_chars"][idx]]
        if frame is not None: SC.frame_set(int(frame))
        return arm.matrix_world.translation.copy() + off
    if s == "sun":
        return Vector(SC["sun_dir"]) * 1000 + off
    name, _, kind = s.partition(":")
    ob = O[name]
    if kind == "top": p = top_point(ob)
    elif kind == "center": mn, mx = bbox_world(ob); p = (mn + mx) / 2
    elif kind == "front":
        mn, mx = bbox_world(ob); fwd = ob.matrix_world.to_3x3() @ Vector((0, -1, 0))
        p = ob.matrix_world.translation + fwd * (max(mx.x - mn.x, mx.y - mn.y) / 2 + 1.0); p.z = ground(p.x, p.y)
    else: p = ob.matrix_world.translation.copy()
    return p + off

# ---------- アニメーション補助 ----------
def fcurves_of(idblock):
    ad = getattr(idblock, "animation_data", None)
    if not ad or not ad.action: return []
    fcs = getattr(ad.action, "fcurves", None)
    if fcs is not None: return list(fcs)
    return [fc for layer in ad.action.layers for strip in layer.strips for cb in strip.channelbags for fc in cb.fcurves]

def set_constant(idblock, frames):
    """frames のキーを CONSTANT にする（カメラのカット）"""
    fs = {int(f) for f in frames}
    for fc in fcurves_of(idblock):
        for kp in fc.keyframe_points:
            if int(round(kp.co.x)) in fs: kp.interpolation = 'CONSTANT'

def yaw_to(v):
    """オブジェクトの正面(-Y)を水平ベクトル v に向ける Z 回転"""
    return math.atan2(v.x, -v.y)

def unwrap(a, ref):
    while a - ref > math.pi: a -= 2 * math.pi
    while a - ref < -math.pi: a += 2 * math.pi
    return a

def smoothstep(t):
    t = max(0.0, min(1.0, t)); return t * t * (3 - 2 * t)
