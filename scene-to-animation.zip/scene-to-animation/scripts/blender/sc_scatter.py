# 原型（parts の proto）をコレクションインスタンスで散布。PLAN["scatter"] は配列で、各要素:
#   protos: {"maple": 0.3, "pine": 0.7}   原型名と割合
#   count(300), area: {"center":[x,y], "r":[rmin,rmax]} or {"rect":[x0,y0,x1,y1]}
#   min_dist(3.2), heights: {"maple":[5.5,8.5], ...}（m）, seed
#   near: {"proto":"maple", "targets":["lake","shrine"], "dist":14, "prob":0.7}   近くでは特定の原型を多めに
# 自動で避ける: 湖(+2.5m)・terrain.clearings・parts の足元（footprints +2m）・PLAN["keep_clear"]（circle [x,y,r] / rect [x0,y0,x1,y1]）
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
import random
col = ensure_col("Scatter")
for o in list(col.objects): bpy.data.objects.remove(o, do_unlink=True)
LK = dict(SC.get("lake", {})) or None
CL = PLAN.get("terrain", {}).get("clearings", [])
FP = [list(f) for f in SC.get("footprints", [])]
KC = PLAN.get("keep_clear", [])
def free(x, y):
    if LK:
        cx, cy = LK["center"]; d = math.hypot(x - cx, (y - cy) * LK.get("squash", 0.85))
        if d < LK["radius"] + 2.5: return False
    for c in CL:
        (cx, cy), (rx, ry) = c["center"], c["radius"]
        if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 < 0.8: return False
    for fx, fy, fr in FP:
        if math.hypot(x - fx, y - fy) < fr + 2.0: return False
    for k in KC:
        if "circle" in k and math.hypot(x - k["circle"][0], y - k["circle"][1]) < k["circle"][2]: return False
        if "rect" in k:
            x0, y0, x1, y1 = k["rect"]
            if min(x0, x1) <= x <= max(x0, x1) and min(y0, y1) <= y <= max(y0, y1): return False
    return True
def target_pos(t):
    if t == "lake" and LK: return LK["center"]
    if t in O: p = O[t].matrix_world.translation; return [p.x, p.y]
    return None
total = 0; msg = []
for si, S in enumerate(PLAN.get("scatter", [])):
    rnd = random.Random(S.get("seed", 7 + si)); names = list(S["protos"].keys()); wts = list(S["protos"].values())
    PC = {n: bpy.data.collections[f"P_{n}"] for n in names}
    near = S.get("near"); tps = [p for p in (target_pos(t) for t in (near or {}).get("targets", [])) if p]
    A = S.get("area", {"center": [0, 0], "r": [10, 80]}); pts = []; tries = 0; md = S.get("min_dist", 3.2)
    while len(pts) < S.get("count", 300) and tries < S.get("count", 300) * 120:
        tries += 1
        if "rect" in A:
            x0, y0, x1, y1 = A["rect"]; x, y = rnd.uniform(x0, x1), rnd.uniform(y0, y1); far = 0
        else:
            r0, r1 = A["r"]; r = r0 + (rnd.random() ** 0.7) * (r1 - r0); a = rnd.random() * 2 * math.pi
            x, y = A["center"][0] + r * math.cos(a), A["center"][1] + r * math.sin(a); far = (r - r0) / max(r1 - r0, 1)
        if not free(x, y): continue
        m = md * (1 + 0.4 * far)
        if any((x - px) ** 2 + (y - py) ** 2 < m * m for px, py, _ in pts[-500:]): continue
        kind = rnd.choices(names, wts)[0]
        if near and any(math.hypot(x - p[0], y - p[1]) < near.get("dist", 14) for p in tps) and rnd.random() < near.get("prob", 0.7):
            kind = near["proto"]
        pts.append((x, y, kind))
    for i, (x, y, kind) in enumerate(pts):
        e = O.new(f"sc{si}_{kind}_{i:03d}", None); col.objects.link(e)
        e.instance_type = 'COLLECTION'; e.instance_collection = PC[kind]; e.empty_display_size = 0.5
        h = rnd.uniform(*S.get("heights", {}).get(kind, [5, 9]))
        e.scale = (h * rnd.uniform(0.9, 1.15), h * rnd.uniform(0.9, 1.15), h)
        e.location = (x, y, ground(x, y) - 0.2); e.rotation_euler = (0, 0, rnd.random() * 2 * math.pi)
    total += len(pts); msg.append(f"#{si}: {len(pts)} ({', '.join(f'{n}={sum(1 for p in pts if p[2]==n)}' for n in names)})")
RESULT = f"scattered {total}: " + " / ".join(msg)
