# キャラクターを .blend から追加し、経路（ウェイポイント）から動きを自動で付ける。PLAN["characters"] の各要素:
#   blend   : "characters/Owl/Owl_rigged.blend"（prompt-to-animated-3d / image-to-rigged-3d の成果物）
#   mesh, armature : オブジェクト名（例 "Owl", "Owl_Armature" / "Kitten", "Creature_Armature"）
#   rig     : "winged" | "quadruped" | "hopper"（ボーン名の規約。prompt-to-animated-3d の rig_*.py と同じ）
#   height  : シーン内の身長[m]
#   path    : ウェイポイントの配列（下記）
# ウェイポイント: {"f": フレーム, "pos": spec（省略 = 直前と同じ場所）, "mode": 次のウェイポイントまでの動き, "face": spec（止まっている間に向く先）}
#   mode: "perch"/"idle"（静止。perch は止まり木）, "fly", "glide"（羽ばたき控えめ）, "walk", "run", "hop"（walk/run/hop は地面を歩く）
#   円軌道: {"f":140, "mode":"fly", "circle":{"center":spec or "lake", "radius":13, "alt":5.5, "end_f":400, "dir":"ccw", "turns":1, "wave":1.5}}
#   静止 → 移動 で自動的に「踏み切り」、移動 → perch で「着地（ブレーキ）」の動きが入る
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
STATIC = {"perch", "idle"}
chars = []
colc = ensure_col("Characters")
for ci, C in enumerate(PLAN.get("characters", [])):
    for n in (C["mesh"], C["armature"]):
        if O.get(n): bpy.data.objects.remove(O[n], do_unlink=True)
    with bpy.data.libraries.load(rpath(C["blend"]), link=False) as (src, dst):
        dst.objects = [n for n in src.objects if n in (C["mesh"], C["armature"])]
    for ob in dst.objects: colc.objects.link(ob)
    arm = next(o for o in dst.objects if o.type == 'ARMATURE'); mesh = next(o for o in dst.objects if o.type == 'MESH')
    mesh.parent = arm
    rig = C.get("rig", "winged")
    # 元の身長（アーマチュアのスケール 1 での mesh の高さ）
    arm.scale = (1, 1, 1); arm.location = (0, 0, 0); arm.rotation_euler = (0, 0, 0)
    if arm.animation_data: arm.animation_data_clear()
    bpy.context.view_layer.update(); mn, mx = bbox_world(mesh); s = C.get("height", 0.5) / (mx.z - mn.z)
    arm.scale = (s, s, s); H = C.get("height", 0.5)
    P = arm.pose.bones
    for pb in P: pb.rotation_mode = 'QUATERNION'; pb.rotation_quaternion = Quaternion(); pb.location = (0, 0, 0); pb.scale = (1, 1, 1)
    arm.animation_data_create(); arm.animation_data.action = bpy.data.actions.new(f"{arm.name}_Scene"); arm.rotation_mode = 'XYZ'

    # ---- ウェイポイントの展開 ----
    W = []; last = None
    for w in C["path"]:
        if "circle" in w:
            c = w["circle"]; cen = c.get("center", "lake")
            cpos = Vector((*SC["lake"]["center"], 0)) if cen == "lake" else resolve(cen)
            cz = cpos.z if (isinstance(cen, (list, tuple)) and len(cen) == 3) else ground(cpos.x, cpos.y)
            prev = W[-1]["p"] if W else cpos + Vector((0, -c["radius"], 0))
            a0 = math.atan2(prev.y - cpos.y, prev.x - cpos.x) if c.get("start_deg") is None else math.radians(c["start_deg"])
            sgn = 1 if c.get("dir", "ccw") == "ccw" else -1; f0, f1 = w["f"], c["end_f"]
            for k in range(0, 101):
                t = k / 100; f = round(f0 + (f1 - f0) * t)
                if W and f <= W[-1]["f"]: continue
                a = a0 + sgn * 2 * math.pi * c.get("turns", 1) * t
                p = Vector((cpos.x + c["radius"] * math.cos(a), cpos.y + c["radius"] * math.sin(a), cz + c.get("alt", 5) + c.get("wave", 1.5) * math.sin(math.pi * t)))
                if k % 5 == 0 or k == 100: W.append({"f": f, "p": p, "mode": w.get("mode", "fly")})
            last = W[-1]["p"]; continue
        p = resolve(w["pos"], w["f"]) if "pos" in w else last
        W.append({"f": w["f"], "p": p, "mode": w.get("mode", "fly"), "face": w.get("face")}); last = p
    W.sort(key=lambda w: w["f"])
    def seg(f):
        for i in range(len(W) - 1):
            if W[i]["f"] <= f <= W[i + 1]["f"]: return i
        return len(W) - 1 if f >= W[-1]["f"] else 0
    def run_of(i):
        a = i
        while a > 0 and W[a - 1]["mode"] not in STATIC: a -= 1
        b = i + 1
        while b < len(W) - 1 and W[b]["mode"] not in STATIC: b += 1
        return a, min(b, len(W) - 1)
    def cr(p0, p1, p2, p3, t):
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3)
    def pos(f):
        i = seg(f); w = W[i]
        if w["mode"] in STATIC or i == len(W) - 1: return w["p"].copy()
        a, b = run_of(i); pts = [W[k]["p"] for k in range(a, b + 1)]; j = i - a
        t = (f - w["f"]) / max(W[i + 1]["f"] - w["f"], 1)
        p0 = pts[max(j - 1, 0)]; p1 = pts[j]; p2 = pts[min(j + 1, len(pts) - 1)]; p3 = pts[min(j + 2, len(pts) - 1)]
        p = cr(p0, p1, p2, p3, t)
        if w["mode"] in ("walk", "run", "hop"):
            p.z = ground(p.x, p.y)
            if w["mode"] == "hop": p.z += 0.35 * H * abs(math.sin(math.pi * (f - w["f"]) / 20))
        return p

    # ---- 位置・向き（オブジェクト）----
    F0, F1 = W[0]["f"], PLAN.get("frames", W[-1]["f"])
    prev_yaw = None; prev_bank = 0.0; arrive_yaw = None
    for f in range(F0, F1 + 1, 2):
        i = seg(f); w = W[i]; p = pos(f); mode = w["mode"] if f < W[-1]["f"] else W[-1]["mode"]
        if mode in STATIC:
            if arrive_yaw is None: arrive_yaw = prev_yaw if prev_yaw is not None else 0.0
            tgt = arrive_yaw
            if w.get("face") is not None:
                q = resolve(w["face"]); v = q - p; v.z = 0
                if v.length > 1e-3: tgt = unwrap(yaw_to(v), arrive_yaw)
            if prev_yaw is None: arrive_yaw = tgt                    # 最初のフレームは最初から face の向き
            yaw = arrive_yaw + (tgt - arrive_yaw) * smoothstep((f - w["f"]) / 24); pitch = 0.0; bank = 0.0
        else:
            arrive_yaw = None
            v = pos(min(f + 3, F1)) - pos(max(f - 3, F0)); v.z = 0
            yaw = yaw_to(v) if v.length > 1e-3 else (prev_yaw or 0.0)
            if prev_yaw is not None: yaw = unwrap(yaw, prev_yaw)
            pitch = bank = 0.0
            if mode in ("fly", "glide"):
                pitch = math.radians(18 if mode == "fly" else 8) * smoothstep((f - w["f"]) / 10 + (0 if W[max(i - 1, 0)]["mode"] in STATIC else 1))
                nxt = W[i + 1] if i + 1 < len(W) else None
                if nxt and nxt["mode"] in STATIC and f > nxt["f"] - 25:
                    pitch = math.radians(-10) + (pitch - math.radians(-10)) * (nxt["f"] - f) / 25
                rate = math.degrees(yaw - (prev_yaw if prev_yaw is not None else yaw)) / 2
                bank = math.radians(max(-30, min(30, rate * 12))); bank = prev_bank * 0.7 + bank * 0.3
            elif mode == "walk" and rig == "winged":
                bank = math.radians(6) * math.sin(math.pi * (f - w["f"]) / 14)
        if prev_yaw is not None: yaw = unwrap(yaw, prev_yaw)
        arm.location = p; arm.rotation_euler = Euler((pitch, bank, yaw), 'XYZ')
        arm.keyframe_insert("location", frame=f); arm.keyframe_insert("rotation_euler", frame=f)
        prev_yaw, prev_bank = yaw, bank

    # ---- ボーン ----
    def wq(name, rots):
        rest = arm.data.bones[name].matrix_local.to_quaternion(); q = Quaternion()
        for ax, deg in rots: q = Quaternion(ax, math.radians(deg)) @ q
        return rest.inverted() @ q @ rest
    def key(name, f, rots=()):
        if name in P and F0 <= f <= F1:
            P[name].rotation_quaternion = wq(name, rots); P[name].keyframe_insert("rotation_quaternion", frame=f)
    def skey(name, f, s3):
        if name in P and F0 <= f <= F1:
            P[name].scale = s3; P[name].keyframe_insert("scale", frame=f)
    def wings(f, up, lag=0.0):
        key("wing1.L", f, [(Y, -up)]); key("wing1.R", f, [(Y, up)]); key("wing2.L", f, [(Y, -lag)]); key("wing2.R", f, [(Y, lag)])
    QL = ["FL", "FR", "BL", "BR"]
    for i in range(len(W) - 1):
        a, b, m = W[i]["f"], W[i + 1]["f"], W[i]["mode"]
        prevm = W[i - 1]["mode"] if i > 0 else m
        if m in STATIC:
            looks = [[(Y, 15), (X, -5)], [(Y, -12)], [(Z, 25)], [(X, 0)]]
            for k, f in enumerate(range(a + 10, b - 5, 28)):
                key("head", f, looks[k % 4])
            key("head", b - 2, [(X, 0)])
            if rig == "winged":
                wings(a, 8); wings(b - 10, 8)
                if b - a > 60:
                    mid = (a + b) // 2; wings(mid - 6, 8); wings(mid, 35, -10); wings(mid + 6, 8); wings(mid + 12, 35, -10); wings(mid + 18, 8)
            elif rig == "quadruped":
                for k, f in enumerate(range(a, b, 6)): key("tail1", f, [(X, -20), (Z, 22 * (1 if k % 2 else -1))])
            elif rig == "hopper":
                for k, f in enumerate(range(a, b, 20)): key("body", f, [(Y, 5 * (1 if k % 2 else -1))])
            nxt = W[i + 1]["mode"]
            if nxt not in STATIC and rig == "winged" and nxt in ("fly", "glide"):          # 踏み切り
                key("body", b - 10, [(X, 0)]); key("body", b, [(X, 14)])
                key("leg.L", b, [(X, -25)]); key("leg.R", b, [(X, -25)]); wings(b - 2, -5)
        elif m in ("fly", "glide"):
            if rig == "winged":
                per = 10
                start = a + (2 if prevm in STATIC else 0)
                for f in range(start, b - (20 if W[i + 1]["mode"] in STATIC else 0), per):
                    if m == "glide": wings(f, 18, -5); wings(f + per // 2, 14, 5)
                    else: wings(f, 72, -25); wings(f + per // 2, -35, 25)
                if prevm in STATIC: wings(a + 2, 80, -25); key("body", a + 4, [(X, 4)])
                for f in range(a + 6, b, 20):
                    key("leg.L", f, [(X, -18)]); key("leg.R", f, [(X, -18)]); key("foot.L", f, [(X, 5)]); key("foot.R", f, [(X, 5)])
                    key("head", f, [(X, -16)]); key("tail", f, [(X, -10), (Z, 6 * math.sin(f * 0.3))])
                if W[i + 1]["mode"] in STATIC:                                             # 着地
                    for f in range(b - 20, b, 10): wings(f, 70, -20); wings(f + 5, -25, 20)
                    key("leg.L", b - 10, [(X, -25)]); key("leg.R", b - 10, [(X, -25)]); key("foot.L", b - 10, [(X, 0)]); key("foot.R", b - 10, [(X, 0)])
                    wings(b, 85, -30); wings(b + 8, 30, -5); wings(b + 16, 8)
                    key("body", b, [(X, -6)]); key("body", b + 10, [(X, 6)]); key("body", b + 20, [(X, 0)])
                    key("leg.L", b + 5, [(X, 0)]); key("leg.R", b + 5, [(X, 0)]); key("head", b + 6, [(X, 0)])
            elif rig == "quadruped":
                for k in QL: key(f"leg_upper.{k}", a, [(X, -40 if k[0] == "F" else 40)]); key(f"leg_lower.{k}", a, [(X, 20 if k[0] == "F" else 0)])
                for k in QL: key(f"leg_upper.{k}", b, [(X, 0)]); key(f"leg_lower.{k}", b, [(X, 0)])
        elif m in ("walk", "run"):
            if rig == "winged":
                for k, f in enumerate(range(a, b, 7)):
                    s1 = 1 if k % 2 == 0 else -1
                    key("leg.L", f, [(X, -22 * s1)]); key("leg.R", f, [(X, 22 * s1)]); key("foot.L", f, [(X, 10 * s1)]); key("foot.R", f, [(X, -10 * s1)])
                    key("head", f, [(Y, -5 * s1), (X, -3)]); wings(f, 6 + 4 * s1, 3); key("tail", f, [(Z, -10 * s1)])
                key("leg.L", b, [(X, 0)]); key("leg.R", b, [(X, 0)]); key("foot.L", b, [(X, 0)]); key("foot.R", b, [(X, 0)])
            elif rig == "quadruped":
                per, sw, lift = (24, 22, 35) if m == "walk" else (12, 32, 55)
                for k, f in enumerate(range(a, b, per // 2)):
                    ph = 1 if k % 2 == 0 else -1
                    for q in ("FL", "BR"): key(f"leg_upper.{q}", f, [(X, -sw * ph)])
                    for q in ("FR", "BL"): key(f"leg_upper.{q}", f, [(X, sw * ph)])
                    fm = f + per // 4
                    for q in (("FL", "BR") if ph < 0 else ("FR", "BL")): key(f"leg_lower.{q}", fm, [(X, lift)])
                    for q in (("FR", "BL") if ph < 0 else ("FL", "BR")): key(f"leg_lower.{q}", fm, [(X, 0)])
                    for q in QL: key(f"leg_lower.{q}", f, [(X, 0)])
                    key("head", f, [(X, 4 * ph)]); key("tail1", f, [(Z, 18 * ph), (X, -10)]); key("tail2", f + 2, [(Z, 25 * ph)])
                for q in QL: key(f"leg_upper.{q}", b, [(X, 0)]); key(f"leg_lower.{q}", b, [(X, 0)])
        elif m == "hop":
            for f in range(a, b, 20):                                                       # スクワッシュ＆ストレッチ
                skey("body", f, (1, 1, 1)); skey("body", f + 3, (1.12, 0.82, 1.12)); skey("body", f + 10, (0.92, 1.12, 0.92)); skey("body", f + 18, (1.15, 0.8, 1.15))
                if rig == "winged": wings(f + 3, 25, -10); wings(f + 10, 5)
            skey("body", b, (1, 1, 1))
    chars.append(arm.name)
SC["scene_chars"] = chars
RESULT = f"characters {chars}"
