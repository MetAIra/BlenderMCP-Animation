# 空（グラデーション＋太陽/月のグロー＋夜は星）と太陽ライト。PLAN["sky"]:
#   preset: "sunset" | "dawn" | "noon" | "night"
#   sun_elevation(度, 既定は preset ごと), sun_azimuth(度。XY 平面で +X=0, +Y=90。夕日を湖の向こうに置く等)
#   sky_strength, sun_energy で微調整
# ※ Blender の物理スカイは低い太陽で白っぽくなるため、手作りのグラデーションを使う
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
S = PLAN.get("sky", {}); P = S.get("preset", "sunset")
PRE = {
    "sunset": dict(el=4, stops=[(0.0, (1.0, 0.50, 0.16)), (0.06, (0.98, 0.36, 0.22)), (0.16, (0.72, 0.28, 0.38)), (0.32, (0.30, 0.18, 0.42)), (0.65, (0.06, 0.07, 0.22))],
                   sun=(1.0, 0.58, 0.28), energy=4.0, glow=(1.0, 0.62, 0.3), disk=40.0, fill=((0.55, 0.45, 0.9), 0.25), stars=0),
    "dawn":   dict(el=6, stops=[(0.0, (1.0, 0.72, 0.55)), (0.08, (0.95, 0.70, 0.70)), (0.25, (0.62, 0.66, 0.85)), (0.6, (0.25, 0.38, 0.65))],
                   sun=(1.0, 0.80, 0.62), energy=3.0, glow=(1.0, 0.8, 0.6), disk=30.0, fill=((0.6, 0.7, 1.0), 0.4), stars=0),
    "noon":   dict(el=55, stops=[(0.0, (0.78, 0.86, 1.0)), (0.2, (0.45, 0.65, 0.95)), (0.6, (0.15, 0.35, 0.85))],
                   sun=(1.0, 0.97, 0.92), energy=4.5, glow=(1.0, 0.98, 0.9), disk=20.0, fill=((0.6, 0.75, 1.0), 0.6), stars=0),
    "night":  dict(el=35, stops=[(0.0, (0.06, 0.08, 0.18)), (0.15, (0.03, 0.04, 0.12)), (0.6, (0.005, 0.008, 0.03))],
                   sun=(0.55, 0.65, 1.0), energy=0.35, glow=(0.8, 0.85, 1.0), disk=25.0, fill=((0.3, 0.35, 0.7), 0.12), stars=1),
}[P]
EL = math.radians(S.get("sun_elevation", PRE["el"])); AZ = math.radians(S.get("sun_azimuth", 90))
sd = Vector((math.cos(EL) * math.cos(AZ), math.cos(EL) * math.sin(AZ), math.sin(EL)))
SC["sun_dir"] = list(sd)
w = SC.world or bpy.data.worlds.new("World"); SC.world = w; w.use_nodes = True
nt = w.node_tree; N = nt.nodes; L = nt.links
for n in list(N): N.remove(n)
out = N.new('ShaderNodeOutputWorld'); bg = N.new('ShaderNodeBackground'); tc = N.new('ShaderNodeTexCoord')
sep = N.new('ShaderNodeSeparateXYZ'); L.new(tc.outputs['Generated'], sep.inputs['Vector'])
mx = N.new('ShaderNodeMath'); mx.operation = 'MAXIMUM'; mx.inputs[1].default_value = 0.0; L.new(sep.outputs['Z'], mx.inputs[0])
ramp = N.new('ShaderNodeValToRGB'); cr = ramp.color_ramp; st = PRE["stops"]
cr.elements[0].position, cr.elements[0].color = st[0][0], (*st[0][1], 1)
cr.elements[1].position, cr.elements[1].color = st[-1][0], (*st[-1][1], 1)
for p, c in st[1:-1]:
    e = cr.elements.new(p); e.color = (*c, 1)
L.new(mx.outputs['Value'], ramp.inputs['Fac'])
dot = N.new('ShaderNodeVectorMath'); dot.operation = 'DOT_PRODUCT'; dot.inputs[1].default_value = tuple(sd)
L.new(tc.outputs['Generated'], dot.inputs[0])
c0 = N.new('ShaderNodeMath'); c0.operation = 'MAXIMUM'; c0.inputs[1].default_value = 0.0; L.new(dot.outputs['Value'], c0.inputs[0])
def pw(e, s):
    p = N.new('ShaderNodeMath'); p.operation = 'POWER'; p.inputs[1].default_value = e; L.new(c0.outputs['Value'], p.inputs[0])
    m = N.new('ShaderNodeMath'); m.operation = 'MULTIPLY'; m.inputs[1].default_value = s; L.new(p.outputs['Value'], m.inputs[0]); return m
terms = [pw(4000, PRE["disk"]), pw(30, 1.2 if P != "night" else 0.4), pw(4, 0.35 if P != "night" else 0.05)]
acc = terms[0]
for t in terms[1:]:
    a = N.new('ShaderNodeMath'); a.operation = 'ADD'; L.new(acc.outputs['Value'], a.inputs[0]); L.new(t.outputs['Value'], a.inputs[1]); acc = a
if PRE["stars"]:   # 星: ボロノイの点を閾値で
    vor = N.new('ShaderNodeTexVoronoi'); vor.inputs['Scale'].default_value = 180; L.new(tc.outputs['Generated'], vor.inputs['Vector'])
    mr = N.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = 0.06; mr.inputs['From Max'].default_value = 0.0
    mr.inputs['To Max'].default_value = 2.5; L.new(vor.outputs['Distance'], mr.inputs['Value'])
    hz = N.new('ShaderNodeMath'); hz.operation = 'MULTIPLY'; L.new(mr.outputs['Result'], hz.inputs[0]); L.new(mx.outputs['Value'], hz.inputs[1])
    a = N.new('ShaderNodeMath'); a.operation = 'ADD'; L.new(acc.outputs['Value'], a.inputs[0]); L.new(hz.outputs['Value'], a.inputs[1]); acc = a
cv = N.new('ShaderNodeCombineXYZ')
for k in ('X', 'Y', 'Z'): L.new(acc.outputs['Value'], cv.inputs[k])
gm = N.new('ShaderNodeMix'); gm.data_type = 'RGBA'; gm.blend_type = 'MULTIPLY'; gm.inputs['Factor'].default_value = 1.0
gm.inputs['A'].default_value = (*PRE["glow"], 1); L.new(cv.outputs['Vector'], gm.inputs['B'])
ad = N.new('ShaderNodeMix'); ad.data_type = 'RGBA'; ad.blend_type = 'ADD'; ad.clamp_result = False; ad.inputs['Factor'].default_value = 1.0
L.new(ramp.outputs['Color'], ad.inputs['A']); L.new(gm.outputs['Result'], ad.inputs['B'])
L.new(ad.outputs['Result'], bg.inputs['Color']); bg.inputs['Strength'].default_value = S.get("sky_strength", 1.0)
L.new(bg.outputs['Background'], out.inputs['Surface'])
env = ensure_col("Environment")
for n in ("Sun", "SkyFill"):
    if O.get(n): bpy.data.objects.remove(O[n], do_unlink=True)
sl = bpy.data.lights.new("Sun", 'SUN'); sl.energy = S.get("sun_energy", PRE["energy"]); sl.color = PRE["sun"]; sl.angle = math.radians(2)
sun = O.new("Sun", sl); env.objects.link(sun); sun.rotation_euler = (-sd).to_track_quat('-Z', 'Y').to_euler()
fl = bpy.data.lights.new("SkyFill", 'SUN'); fl.color, fl.energy = PRE["fill"]
fill = O.new("SkyFill", fl); env.objects.link(fill); fill.rotation_euler = (math.radians(30), 0, AZ + math.pi * 0.8)
try: SC.view_settings.view_transform = 'AgX'
except Exception: pass
RESULT = f"sky {P}: el={math.degrees(EL):.1f} az={math.degrees(AZ):.0f}"
