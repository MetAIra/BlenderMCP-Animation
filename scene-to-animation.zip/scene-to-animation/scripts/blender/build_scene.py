# plan.json からシーンを組み立てるドライバー
# PARAMS: plan（plan.json のパス。プロジェクト相対可）, steps（既定 全部）, render（sc_render の PARAMS。省略でレンダーしない）, save（.blend のパス）
#   steps: "terrain", "sky", "parts", "scatter", "characters", "camera"
#   例: カメラだけ直す → steps=["camera"]、キャラの経路だけ → ["characters","camera"]（camera は characters に依存）
# 呼び出し:
#   g = {"SKILL": SKILL, "ROOT": ROOT, "PARAMS": {"plan": "scenes/X/plan.json", "render": {"mode":"frames","out_dir":"..."}}}
#   exec(open(SKILL + r"\scripts\blender\build_scene.py", encoding="utf-8").read(), g); raise Exception(g["RESULT"])
import json, os, traceback, bpy
_P = PARAMS
def _abs(p): return p if (":" in p[:3]) else os.path.join(ROOT, p.replace("/", "\\"))
PLAN = json.load(open(_abs(_P["plan"]), encoding="utf-8"))
ORDER = [("terrain", "sc_terrain.py"), ("sky", "sc_sky.py"), ("parts", "sc_parts.py"), ("scatter", "sc_scatter.py"),
         ("characters", "sc_character.py"), ("camera", "sc_camera.py")]
steps = _P.get("steps", [k for k, _ in ORDER]); log = []
for key, fn in ORDER:
    if key not in steps: continue
    g = {"SKILL": SKILL, "ROOT": ROOT, "PLAN": PLAN, "PARAMS": _P.get(key, {})}
    try: exec(open(os.path.join(SKILL, "scripts", "blender", fn), encoding="utf-8").read(), g)
    except Exception: raise Exception(f"[{key}] " + traceback.format_exc()[-900:])
    log.append(f"{key}: {g.get('RESULT')}")
if _P.get("save"): bpy.ops.wm.save_as_mainfile(filepath=_abs(_P["save"]))
if _P.get("render"):
    g = {"SKILL": SKILL, "ROOT": ROOT, "PLAN": PLAN, "PARAMS": _P["render"]}
    try: exec(open(os.path.join(SKILL, "scripts", "blender", "sc_render.py"), encoding="utf-8").read(), g)
    except Exception: raise Exception("[render] " + traceback.format_exc()[-900:])
    log.append(f"render: {g.get('RESULT')}")
RESULT = " | ".join(log)
