# レンダー。PARAMS: mode "frames"|"video", out_dir, frames([...] 省略時は各ショットの中間+終端), res, samples, name
#   PLAN["render"]: exposure(0), bloom(0.35), fill_energy（SkyFill の強さを上書き）
# EEVEE（レイトレース反射）。ワールドのボリューム（霞）は EEVEE で画面が真っ黒になるので使わない
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
import os
R = PLAN.get("render", {})
SC.render.engine = 'BLENDER_EEVEE'
for attr, val in (("use_raytracing", True), ("taa_render_samples", prm("samples", 48 if prm("mode") == "video" else 24))):
    try: setattr(SC.eevee, attr, val)
    except Exception: pass
try:
    ng = bpy.data.node_groups.get("Scene_Comp") or bpy.data.node_groups.new("Scene_Comp", 'CompositorNodeTree')
    for n in list(ng.nodes): ng.nodes.remove(n)
    rl = ng.nodes.new('CompositorNodeRLayers'); gl = ng.nodes.new('CompositorNodeGlare')
    if not any(getattr(s, 'in_out', '') == 'OUTPUT' for s in ng.interface.items_tree):
        ng.interface.new_socket("Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    go = ng.nodes.new('NodeGroupOutput')
    ng.links.new(rl.outputs['Image'], gl.inputs['Image']); ng.links.new(gl.outputs['Image'], go.inputs[0])
    gl.inputs['Type'].default_value = 'Bloom'; gl.inputs['Quality'].default_value = 'High'
    gl.inputs['Threshold'].default_value = 1.2; gl.inputs['Strength'].default_value = R.get("bloom", 0.35); gl.inputs['Size'].default_value = 0.7
    SC.compositing_node_group = ng; SC.render.use_compositing = True
except Exception as e:
    print("bloom skipped", e)
SC.view_settings.exposure = R.get("exposure", 0.0)
if "fill_energy" in R and O.get("SkyFill"): O["SkyFill"].data.energy = R["fill_energy"]
out = rpath(prm("out_dir")); os.makedirs(out, exist_ok=True)
im = SC.render.image_settings
if prm("mode", "frames") == "frames":
    try: im.media_type = 'IMAGE'
    except Exception: pass
    im.file_format = 'PNG'
    SC.render.resolution_x, SC.render.resolution_y = prm("res", [960, 540])
    frames = prm("frames")
    if not frames:
        frames = []
        for s in PLAN.get("shots", []): frames += [s["f"][0] + 2, (s["f"][0] + s["f"][1]) // 2, s["f"][1] - 2]
    paths = []
    for f in frames:
        SC.frame_set(int(f)); p = os.path.join(out, f"f{int(f):03d}.png"); SC.render.filepath = p
        bpy.ops.render.render(write_still=True); paths.append(p)
    RESULT = f"{len(paths)} frames -> {out}"
else:
    try: im.media_type = 'VIDEO'
    except Exception: pass
    im.file_format = 'FFMPEG'
    ff = SC.render.ffmpeg; ff.format = 'MPEG4'; ff.codec = 'H264'; ff.constant_rate_factor = 'HIGH'
    SC.render.resolution_x, SC.render.resolution_y = prm("res", [1280, 720])
    SC.render.filepath = os.path.join(out, prm("name", PLAN.get("name", "scene") + "_"))
    bpy.ops.render.render(animation=True)
    RESULT = f"video {SC.render.filepath}{SC.frame_start:04d}-{SC.frame_end:04d}.mp4"
