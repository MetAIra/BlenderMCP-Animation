# 地形＋水面。PLAN["terrain"]:
#   size(260), res(220), center([0,20])   グリッドの大きさ・分割・中心
#   lake: {"center":[x,y], "radius":r, "depth":2.2, "squash":0.85} or null
#   mountains: {"height":20, "start":45, "width":60, "gap_deg":<太陽方位>, "gap_depth":0.85} or null
#   clearings: [{"center":[x,y], "radius":[rx,ry]}]   平らにする場所（建物・参道）
#   noise: 0.6   起伏
#   palette: "grass" | "autumn" | "snow" | "desert"
# 既存のシーンを全部消してから作る（PARAMS["clear"]=False で消さない）
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
T = PLAN.get("terrain", {})
if prm("clear", True):
    for o in list(O): bpy.data.objects.remove(o, do_unlink=True)
    for c in list(bpy.data.collections): bpy.data.collections.remove(c)
LK = T.get("lake"); MT = T.get("mountains", {"height": 20}); CL = T.get("clearings", [])
sky = PLAN.get("sky", {}); sun_az = math.radians(sky.get("sun_azimuth", 90))
NA = T.get("noise", 0.6)
def height(x, y):
    h = np.zeros_like(x); shore = np.ones_like(x)
    if LK:
        cx, cy = LK["center"]; r = LK["radius"]; sq = LK.get("squash", 0.85)
        d = np.hypot(x - cx, (y - cy) * sq)
        h -= LK.get("depth", 2.2) * np.clip(1 - d / r, 0, 1) ** 0.6
        shore = np.clip((d - r) / 6, 0, 1)
    n = np.sin(x * 0.11) * np.cos(y * 0.09) + 0.5 * np.sin(x * 0.23 + y * 0.17) + 0.25 * np.sin(x * 0.5 - y * 0.41)
    hills = 0
    if MT:
        c = T.get("center", [0, 20]); rr = np.hypot(x - c[0], y - c[1])
        ang = np.arctan2(y - c[1], x - c[0])
        gd = math.radians(MT.get("gap_deg", math.degrees(sun_az)))
        dang = np.angle(np.exp(1j * (ang - gd)))
        gap = 1 - MT.get("gap_depth", 0.85) * np.exp(-(dang / 0.45) ** 2)
        hills = np.clip((rr - MT.get("start", 45)) / MT.get("width", 60), 0, 1) ** 1.6 * MT.get("height", 20) * gap
    h += shore * (NA * n + hills * (0.75 + 0.25 * n))
    for cl in CL:
        (cx, cy), (rx, ry) = cl["center"], cl["radius"]
        h *= 1 - np.exp(-(((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2))
    return h
N = T.get("res", 220); S = T.get("size", 260.0); c = T.get("center", [0, 20])
xs = np.linspace(c[0] - S / 2, c[0] + S / 2, N); ys = np.linspace(c[1] - S / 2, c[1] + S / 2, N)
Xg, Yg = np.meshgrid(xs, ys); Zh = height(Xg, Yg)
me = bpy.data.meshes.new("Terrain")
me.from_pydata(np.stack([Xg.ravel(), Yg.ravel(), Zh.ravel()], 1).tolist(), [],
               [(i * N + j, i * N + j + 1, (i + 1) * N + j + 1, (i + 1) * N + j) for i in range(N - 1) for j in range(N - 1)])
me.update()
for p in me.polygons: p.use_smooth = True
ter = O.new("Terrain", me); env = ensure_col("Environment"); env.objects.link(ter)
PAL = {
    "grass":  [(0.0, (0.35, 0.29, 0.2)), (0.045, (0.16, 0.26, 0.07)), (0.45, (0.22, 0.32, 0.09)), (0.75, (0.12, 0.2, 0.08))],
    "autumn": [(0.0, (0.35, 0.29, 0.2)), (0.045, (0.30, 0.26, 0.10)), (0.45, (0.38, 0.26, 0.10)), (0.75, (0.25, 0.16, 0.08))],
    "snow":   [(0.0, (0.55, 0.58, 0.62)), (0.045, (0.85, 0.88, 0.92)), (0.45, (0.92, 0.94, 0.97)), (0.75, (0.97, 0.98, 1.0))],
    "desert": [(0.0, (0.55, 0.42, 0.28)), (0.045, (0.78, 0.62, 0.40)), (0.45, (0.72, 0.55, 0.35)), (0.75, (0.60, 0.42, 0.28))],
}[T.get("palette", "grass")]
m = bpy.data.materials.new("Terrain"); m.use_nodes = True; nt = m.node_tree; Nn = nt.nodes; L = nt.links
b = next(n for n in Nn if n.type == 'BSDF_PRINCIPLED'); b.inputs['Roughness'].default_value = 0.95
geo = Nn.new('ShaderNodeNewGeometry'); sxyz = Nn.new('ShaderNodeSeparateXYZ'); L.new(geo.outputs['Position'], sxyz.inputs['Vector'])
noise = Nn.new('ShaderNodeTexNoise'); noise.inputs['Scale'].default_value = 0.15; noise.inputs['Detail'].default_value = 6
nm = Nn.new('ShaderNodeMath'); nm.operation = 'MULTIPLY'; nm.inputs[1].default_value = 1.2; L.new(noise.outputs['Fac'], nm.inputs[0])
add = Nn.new('ShaderNodeMath'); add.operation = 'ADD'; L.new(sxyz.outputs['Z'], add.inputs[0]); L.new(nm.outputs['Value'], add.inputs[1])
mr = Nn.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = -1.0; mr.inputs['From Max'].default_value = 22
L.new(add.outputs['Value'], mr.inputs['Value'])
ramp = Nn.new('ShaderNodeValToRGB'); cr = ramp.color_ramp
cr.elements[0].position, cr.elements[0].color = PAL[0][0], (*PAL[0][1], 1)
cr.elements[1].position, cr.elements[1].color = PAL[1][0], (*PAL[1][1], 1)
for p, col in PAL[2:]:
    e = cr.elements.new(p); e.color = (*col, 1)
L.new(mr.outputs['Result'], ramp.inputs['Fac']); L.new(ramp.outputs['Color'], b.inputs['Base Color'])
ter.data.materials.append(m)
if LK:
    bpy.ops.mesh.primitive_circle_add(vertices=128, radius=LK["radius"] * 1.25, fill_type='NGON',
                                      location=(LK["center"][0], LK["center"][1], -0.35))
    wat = bpy.context.object; wat.name = "Lake"; to_col(wat, env)
    wm = bpy.data.materials.new("Water"); wm.use_nodes = True; wn = wm.node_tree.nodes; wl = wm.node_tree.links
    wb = next(n for n in wn if n.type == 'BSDF_PRINCIPLED')
    wb.inputs['Base Color'].default_value = (0.02, 0.05, 0.07, 1); wb.inputs['Roughness'].default_value = 0.04; wb.inputs['IOR'].default_value = 1.33
    wv = wn.new('ShaderNodeTexNoise'); wv.noise_dimensions = '4D'; wv.inputs['Scale'].default_value = 1.6; wv.inputs['Detail'].default_value = 4
    bump = wn.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.12; bump.inputs['Distance'].default_value = 0.05
    wl.new(wv.outputs['Fac'], bump.inputs['Height']); wl.new(bump.outputs['Normal'], wb.inputs['Normal'])
    fr = PLAN.get("frames", 600)
    wv.inputs['W'].default_value = 0.0; wv.inputs['W'].keyframe_insert('default_value', frame=1)
    wv.inputs['W'].default_value = fr / 200; wv.inputs['W'].keyframe_insert('default_value', frame=fr)
    wat.data.materials.append(wm)
SC["lake"] = LK or {}
SC.frame_start, SC.frame_end = 1, PLAN.get("frames", 600); SC.render.fps = PLAN.get("fps", 30)
RESULT = f"terrain {len(me.polygons)} faces, lake={bool(LK)}, palette={T.get('palette', 'grass')}"
