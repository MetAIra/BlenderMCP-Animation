# カメラワーク。PLAN["shots"] の配列（フレーム順・重ならないように）。ショットの境目は自動でカット（CONSTANT 補間）
#   共通: f [開始, 終了], lens(35 or [開始, 終了])
#   static: pos spec, look spec（"char" ならキャラを追って首振り）
#   dolly : from spec, to spec, look spec（または look_from / look_to）
#   chase : char(0), dist(4.2), height(1.2), side(1.0。進行方向の右側=正), ahead(2.0 注視点を前に), smooth(0.6)
#   orbit : center spec, radius(8), height(3), deg [開始, 終了]（+X=0, 反時計回り）, look spec（省略で center）
# 注意: chase は建物を突き抜けやすい → くぐる/狭い場面は static や dolly にする
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
cam = O.get("Cam")
if cam is None:
    cam = O.new("Cam", bpy.data.cameras.new("Cam")); SC.collection.objects.link(cam)
SC.camera = cam; cam.constraints.clear(); cam.parent = None
if cam.animation_data: cam.animation_data_clear()
if cam.data.animation_data: cam.data.animation_data_clear()
tgt = O.get("CamLook") or O.new("CamLook", None)
if tgt.name not in SC.collection.objects: SC.collection.objects.link(tgt)
if tgt.animation_data: tgt.animation_data_clear()
tr = cam.constraints.new('TRACK_TO'); tr.target = tgt; tr.track_axis = 'TRACK_NEGATIVE_Z'; tr.up_axis = 'UP_Y'
cam.data.clip_end = 1000
def k(f, cpos, look, lens):
    cam.location = cpos; cam.data.lens = lens; tgt.location = look
    cam.keyframe_insert("location", frame=f); cam.data.keyframe_insert("lens", frame=f); tgt.keyframe_insert("location", frame=f)
def lens_at(s, t):
    L = s.get("lens", 35); return L if not isinstance(L, (list, tuple)) else L[0] + (L[1] - L[0]) * t
cuts = []
for s in PLAN.get("shots", []):
    f0, f1 = s["f"]; typ = s.get("type", "static"); last = f0
    if typ == "static":
        p = resolve(s["pos"], f0); dyn = str(s.get("look", "")).startswith("char")
        for f in (range(f0, f1 + 1, 3) if dyn else (f0, f1)):
            k(f, p, resolve(s["look"], f), lens_at(s, (f - f0) / max(f1 - f0, 1))); last = f
    elif typ == "dolly":
        dyn = any(str(s.get(x, "")).startswith("char") for x in ("look", "from", "to"))
        for f in (range(f0, f1 + 1, 3) if dyn else (f0, f1)):
            t = (f - f0) / max(f1 - f0, 1); te = smoothstep(t)
            a, b = resolve(s["from"], f), resolve(s["to"], f)
            look = resolve(s["look"], f) if "look" in s else resolve(s["look_from"], f).lerp(resolve(s["look_to"], f), te)
            k(f, a.lerp(b, te), look, lens_at(s, t)); last = f
    elif typ == "chase":
        ch = s.get("char", 0); prev = None
        for f in range(f0, f1 + 1, 4):
            p = resolve(f"char{ch}", f); q = resolve(f"char{ch}", min(f + 6, SC.frame_end)); v = q - p; v.z = 0
            v = v.normalized() if v.length > 1e-3 else Vector((0, 1, 0)); right = Vector((v.y, -v.x, 0))
            c = p - v * s.get("dist", 4.2) + Vector((0, 0, s.get("height", 1.2))) + right * s.get("side", 1.0)
            if prev is not None: c = prev.lerp(c, s.get("smooth", 0.6))
            k(f, c, p + v * s.get("ahead", 2.0) + Vector((0, 0, 0.2)), lens_at(s, (f - f0) / max(f1 - f0, 1))); prev = c; last = f
    elif typ == "orbit":
        d0, d1 = s.get("deg", [0, 90]); r = s.get("radius", 8); hgt = s.get("height", 3)
        for f in range(f0, f1 + 1, 3):
            t = (f - f0) / max(f1 - f0, 1); a = math.radians(d0 + (d1 - d0) * t); c = resolve(s["center"], f)
            k(f, c + Vector((r * math.cos(a), r * math.sin(a), hgt)), resolve(s.get("look", s["center"]), f), lens_at(s, t)); last = f
    cuts.append(last)
for idb in (cam, tgt, cam.data): set_constant(idb, cuts[:-1])
SC.frame_set(1)
RESULT = f"{len(PLAN.get('shots', []))} shots, cuts at {cuts[:-1]}"
