# Blender で作る（手続き的な）建物・小物。sc_parts.py から exec され、BUILDERS[type](name, params, entry) を提供
# どれも「正面 = -Y」で作り、sc_parts が pos/yaw で配置する（path/fence/bridge は世界座標の点で作る）
import bmesh, random

def mat(name, color, rough=0.7, emit=None, metal=0.0):
    m = bpy.data.materials.get(name)
    if m: return m
    m = bpy.data.materials.new(name); m.use_nodes = True
    b = next(n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    b.inputs['Base Color'].default_value = (*color, 1); b.inputs['Roughness'].default_value = rough; b.inputs['Metallic'].default_value = metal
    if emit:
        b.inputs['Emission Color'].default_value = (*emit[0], 1); b.inputs['Emission Strength'].default_value = emit[1]
    return m

def new_obj(name, bm, mats):
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    for mm in mats: me.materials.append(mm)
    ob = O.new(name, me); return ob

def box(bm, cx, cy, cz, sx, sy, sz, mi=0):
    r = bmesh.ops.create_cube(bm, size=1.0)
    for v in r['verts']: v.co = Vector((cx + v.co.x * sx, cy + v.co.y * sy, cz + v.co.z * sz))
    for f in {f for v in r['verts'] for f in v.link_faces}: f.material_index = mi
    return r['verts']

# ---------- 家（切妻屋根） ----------
def b_house(name, p, e):
    """params: w(6), d(5), h(3), roof_h(2.2), overhang(0.4), wall/roof/trim/door 色, windows(2), lit(False=夜に窓を光らせる)"""
    w, d, h, rh, oh = p.get("w", 6), p.get("d", 5), p.get("h", 3), p.get("roof_h", 2.2), p.get("overhang", 0.4)
    M = [mat(f"{name}_wall", p.get("wall", (0.85, 0.80, 0.70))), mat(f"{name}_roof", p.get("roof", (0.25, 0.12, 0.10)), 0.6),
         mat(f"{name}_trim", p.get("trim", (0.35, 0.22, 0.14))), mat(f"{name}_door", p.get("door", (0.30, 0.18, 0.10))),
         mat(f"{name}_win", (0.15, 0.2, 0.25), 0.1, emit=((1.0, 0.7, 0.35), 6.0) if p.get("lit") else None)]
    bm = bmesh.new()
    box(bm, 0, 0, h / 2 + 0.25, w, d, h, 0)                                  # 壁
    box(bm, 0, 0, 0.125, w + 0.3, d + 0.3, 0.25, 2)                          # 土台
    for sx in (-1, 1):                                                       # 柱（角）
        for sy in (-1, 1): box(bm, sx * w / 2, sy * d / 2, h / 2 + 0.25, 0.22, 0.22, h, 2)
    # 屋根（切妻: 前後方向に傾斜。棟は X 方向）
    zb = h + 0.25; L = w + 2 * oh; D = d / 2 + oh; th = 0.18
    for s in (-1, 1):
        r = bmesh.ops.create_cube(bm, size=1.0)
        ang = math.atan2(rh, D); ln = math.hypot(rh, D)
        for v in r['verts']:
            lx, ly, lz = v.co.x * L, (v.co.y + 0.5) * ln, v.co.z * th
            yy = ly * math.cos(ang) - lz * math.sin(ang); zz = ly * math.sin(ang) + lz * math.cos(ang)
            v.co = Vector((lx, s * (D - yy), zb + zz))
        for f in {f for v in r['verts'] for f in v.link_faces}: f.material_index = 1
    # 妻壁（三角）
    for sx in (-1, 1):
        vs = [bm.verts.new((sx * w / 2, -d / 2, zb)), bm.verts.new((sx * w / 2, d / 2, zb)), bm.verts.new((sx * w / 2, 0, zb + rh * (d / 2) / D))]
        f = bm.faces.new(vs if sx > 0 else vs[::-1]); f.material_index = 0
    box(bm, 0, -d / 2 - 0.03, 0.25 + 1.05, 1.0, 0.08, 2.1, 3)                # 扉
    nwin = p.get("windows", 2)
    for i in range(nwin):
        x = (i - (nwin - 1) / 2) * (w / (nwin + 1)) * 1.6
        if abs(x) < 1.0: continue
        box(bm, x, -d / 2 - 0.03, 0.25 + h * 0.6, 0.9, 0.08, 0.8, 4)
        box(bm, x, d / 2 + 0.03, 0.25 + h * 0.6, 0.9, 0.08, 0.8, 4)
    for sx in (-1, 1): box(bm, sx * (w / 2 + 0.03), 0, 0.25 + h * 0.6, 0.08, 0.9, 0.8, 4)
    return new_obj(name, bm, M)

# ---------- 石畳の道 ----------
def b_stone_path(name, p, e):
    """params: points [[x,y],...]（世界座標）, width(1.6), stone(0.32), color"""
    pts = [Vector((q[0], q[1], 0)) for q in p["points"]]; wd = p.get("width", 1.6); st = p.get("stone", 0.32)
    rnd = random.Random(p.get("seed", 1)); bm = bmesh.new()
    for a, b in zip(pts[:-1], pts[1:]):
        seg = b - a; n = max(1, int(seg.length / (st * 1.1))); side = Vector((-seg.y, seg.x, 0)).normalized()
        for i in range(n):
            c = a + seg * ((i + 0.5) / n)
            for k in range(max(1, int(wd / (st * 1.2)))):
                o = c + side * ((k - (wd / (st * 1.2) - 1) / 2) * st * 1.15 + rnd.uniform(-0.08, 0.08))
                rr = st * rnd.uniform(0.42, 0.55)
                r = bmesh.ops.create_cone(bm, cap_ends=True, segments=7, radius1=rr, radius2=rr * 0.85, depth=0.12)
                z = ground(o.x, o.y) + 0.02
                for v in r['verts']: v.co = Vector((o.x + v.co.x, o.y + v.co.y, z + v.co.z))
    return new_obj(name, bm, [mat(f"{name}_stone", p.get("color", (0.36, 0.34, 0.32)), 0.9)])

# ---------- 岩 ----------
def b_rocks(name, p, e):
    """params: center [x,y], radius(6), count(8), size([0.4,1.4]), color"""
    rnd = random.Random(p.get("seed", 3)); bm = bmesh.new(); cx, cy = p.get("center", [0, 0])
    for i in range(p.get("count", 8)):
        a = rnd.random() * 2 * math.pi; r = p.get("radius", 6) * math.sqrt(rnd.random())
        x, y = cx + r * math.cos(a), cy + r * math.sin(a); s = rnd.uniform(*p.get("size", [0.4, 1.4]))
        res = bmesh.ops.create_icosphere(bm, subdivisions=2, radius=1.0)
        z = ground(x, y)
        for v in res['verts']:
            n = 1 + 0.25 * math.sin(v.co.x * 3.1 + i) * math.cos(v.co.y * 2.7 + i * 0.7) + rnd.uniform(-0.06, 0.06)
            v.co = Vector((x + v.co.x * s * n * 1.2, y + v.co.y * s * n, z + max(v.co.z, -0.3) * s * n * 0.7))
    ob = new_obj(name, bm, [mat(f"{name}_rock", p.get("color", (0.38, 0.37, 0.35)), 0.95)])
    for f in ob.data.polygons: f.use_smooth = True
    return ob

# ---------- 太鼓橋 ----------
def b_bridge(name, p, e):
    """params: a [x,y], b [x,y], width(2.2), arch(1.2), color(朱), planks(24)"""
    A = Vector((*p["a"], 0)); B = Vector((*p["b"], 0)); A.z = ground(A.x, A.y); B.z = ground(B.x, B.y)
    seg = B - A; L = Vector((seg.x, seg.y, 0)).length; dirv = Vector((seg.x, seg.y, 0)).normalized(); side = Vector((-dirv.y, dirv.x, 0))
    wd = p.get("width", 2.2); ar = p.get("arch", 1.2); n = p.get("planks", 24); bm = bmesh.new()
    def at(t): q = A.lerp(B, t); q.z += ar * math.sin(math.pi * t) + 0.3; return q
    for i in range(n):
        t0, t1 = i / n, (i + 1) / n; c = (at(t0) + at(t1)) / 2; vs = box(bm, 0, 0, 0, L / n * 0.95, wd, 0.12, 0)
        rot = Matrix.Rotation(math.atan2(dirv.y, dirv.x), 4, 'Z') @ Matrix.Rotation(-math.atan2(at(t1).z - at(t0).z, L / n), 4, 'Y')
        bmesh.ops.transform(bm, matrix=Matrix.Translation(c) @ rot, verts=vs)
    for k in range(n + 1):                                                    # 欄干の柱と手すり
        if k % 3: continue
        t = k / n
        for s in (-1, 1):
            q = at(t) + side * s * (wd / 2); vs = box(bm, q.x, q.y, q.z + 0.45, 0.12, 0.12, 0.9, 1)
    for s in (-1, 1):
        for i in range(n):
            q0 = at(i / n) + side * s * (wd / 2) + Vector((0, 0, 0.85)); q1 = at((i + 1) / n) + side * s * (wd / 2) + Vector((0, 0, 0.85))
            c = (q0 + q1) / 2; d = q1 - q0; vs = box(bm, 0, 0, 0, d.length, 0.1, 0.1, 1)
            rot = Matrix.Rotation(math.atan2(d.y, d.x), 4, 'Z') @ Matrix.Rotation(-math.atan2(d.z, Vector((d.x, d.y, 0)).length), 4, 'Y')
            bmesh.ops.transform(bm, matrix=Matrix.Translation(c) @ rot, verts=vs)
    for t in (0.18, 0.5, 0.82):                                               # 橋脚
        q = at(t)
        for s in (-1, 1):
            g = ground(q.x + side.x * s * wd * 0.4, q.y + side.y * s * wd * 0.4) - 0.8; hgt = q.z - g
            box(bm, q.x + side.x * s * wd * 0.4, q.y + side.y * s * wd * 0.4, g + hgt / 2, 0.25, 0.25, hgt, 1)
    return new_obj(name, bm, [mat(f"{name}_deck", p.get("deck", (0.45, 0.30, 0.18))), mat(f"{name}_rail", p.get("color", (0.85, 0.18, 0.08)), 0.5)])

# ---------- 柵 ----------
def b_fence(name, p, e):
    """params: points [[x,y],...], height(1.0), spacing(1.5), color"""
    pts = [Vector((q[0], q[1], 0)) for q in p["points"]]; h = p.get("height", 1.0); sp = p.get("spacing", 1.5); bm = bmesh.new()
    posts = []
    for a, b in zip(pts[:-1], pts[1:]):
        n = max(1, int((b - a).length / sp))
        for i in range(n): posts.append(a.lerp(b, i / n))
    posts.append(pts[-1])
    for q in posts:
        q.z = ground(q.x, q.y); box(bm, q.x, q.y, q.z + h / 2, 0.12, 0.12, h, 0)
    for q0, q1 in zip(posts[:-1], posts[1:]):
        for zz in (0.35, 0.8):
            c = (q0 + q1) / 2; d = q1 - q0; vs = box(bm, 0, 0, 0, d.length, 0.06, 0.08, 0)
            rot = Matrix.Rotation(math.atan2(d.y, d.x), 4, 'Z') @ Matrix.Rotation(-math.atan2(d.z, Vector((d.x, d.y, 0)).length), 4, 'Y')
            bmesh.ops.transform(bm, matrix=Matrix.Translation(c + Vector((0, 0, zz * h))) @ rot, verts=vs)
    return new_obj(name, bm, [mat(f"{name}_wood", p.get("color", (0.42, 0.30, 0.20)))])

# ---------- 明かり（夜の灯籠・街灯・窓） ----------
def b_light(name, p, e):
    """params: color(暖色), energy(W, 60), radius(0.2), bulb(True=光る球も置く), size(0.12), post(True: lift>0.3 なら支柱と笠を付ける)"""
    ld = bpy.data.lights.new(name, 'POINT'); ld.color = p.get("color", (1.0, 0.65, 0.3)); ld.energy = p.get("energy", 60)
    ld.shadow_soft_size = p.get("radius", 0.2)
    ob = O.new(name, ld)
    if p.get("bulb", True):
        bm = bmesh.new(); bmesh.ops.create_uvsphere(bm, u_segments=12, v_segments=8, radius=p.get("size", 0.12))
        bulb = new_obj(name + "_bulb", bm, [mat(name + "_glow", p.get("color", (1.0, 0.65, 0.3)), emit=(p.get("color", (1.0, 0.65, 0.3)), 15))])
        bulb.parent = ob; e["_extra"] = [bulb]
    lift = e.get("lift", 0.0)
    if lift > 0.3 and p.get("post", True):                                     # 支柱（地面から明かりまで）と笠
        bm = bmesh.new(); box(bm, 0, 0, -lift / 2 - 0.08, 0.07, 0.07, lift - 0.1, 0)
        r = bmesh.ops.create_cone(bm, cap_ends=True, segments=8, radius1=0.2, radius2=0.04, depth=0.12)
        for v in r['verts']: v.co.z += 0.16
        post = new_obj(name + "_post", bm, [mat("lamp_post", p.get("post_color", (0.12, 0.10, 0.09)), 0.6)])
        post.parent = ob; e["_extra"].append(post)
    return ob

# ---------- 台・広場（平たい円/四角） ----------
def b_platform(name, p, e):
    """params: shape("circle"|"rect"), size([w,d] or r), h(0.3), color"""
    bm = bmesh.new()
    if p.get("shape", "circle") == "circle":
        r = bmesh.ops.create_cone(bm, cap_ends=True, segments=48, radius1=p.get("size", 4), radius2=p.get("size", 4), depth=p.get("h", 0.3))
        for v in r['verts']: v.co.z += p.get("h", 0.3) / 2
    else:
        w, d = p.get("size", [6, 6]); box(bm, 0, 0, p.get("h", 0.3) / 2, w, d, p.get("h", 0.3), 0)
    return new_obj(name, bm, [mat(f"{name}_mat", p.get("color", (0.55, 0.52, 0.48)), 0.85)])

BUILDERS = {"house": b_house, "stone_path": b_stone_path, "rocks": b_rocks, "bridge": b_bridge,
            "fence": b_fence, "light": b_light, "platform": b_platform}
WORLD_SPACE = {"stone_path", "rocks", "bridge", "fence"}     # pos/yaw を使わず世界座標で作るもの
