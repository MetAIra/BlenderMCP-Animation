# Blender をバックグラウンドで起動して動画をレンダーする（MCP 経由の長時間レンダーで接続が切れるのを避ける）
# 使い方（PowerShell）:
#   & "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" -b <scene.blend> --python bg_render.py -- <plan.json> <out_dir> [name]
import sys, json, os
argv = sys.argv[sys.argv.index("--") + 1:]
SKILL = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(SKILL)))
plan_path, out_dir = argv[0], argv[1]
PLAN = json.load(open(plan_path, encoding="utf-8"))
g = {"SKILL": SKILL, "ROOT": ROOT, "PLAN": PLAN,
     "PARAMS": {"mode": "video", "out_dir": out_dir, "name": argv[2] if len(argv) > 2 else PLAN.get("name", "scene") + "_"}}
exec(open(os.path.join(SKILL, "scripts", "blender", "sc_render.py"), encoding="utf-8").read(), g)
print("BG_RENDER_DONE", g["RESULT"])
