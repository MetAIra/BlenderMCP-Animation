# 建物・小物を配置する。PLAN["parts"] の各要素:
#   共通: name, pos [x,y]（地面に自動で乗る）or [x,y,z], yaw(度。正面 -Y が基準。180 で +Y 向き), sink(0.05 埋める量), lift(地面からの高さ。明かり等)
#   source "ai"     : dir（assets/parts/<part> など Hunyuan3D 出力フォルダ。tex/textured_mesh.obj を読む）, height[m], squash [sx,sy,sz], rough [min,max]
#   source "blender": type（house / stone_path / rocks / bridge / fence / light / platform）, params{...}
#   source "copy"   : copy_of（既存パーツ名）
#   proto: true     : 森などの散布用の原型（シーンには置かない。height は 1.0 で読み、散布時に拡大）
#   tone [hue, sat, val]: 色味の調整（0.5,1,1 = そのまま）
exec(open(SKILL + r"\scripts\blender\sc_common.py", encoding="utf-8").read(), globals())
exec(open(SKILL + r"\scripts\blender\sc_builders.py", encoding="utf-8").read(), globals())
import os
col = ensure_col("Parts")
def load_ai(name, d, height, rough=(0.4, 0.9)):
    if O.get(name): bpy.data.objects.remove(O[name], do_unlink=True)
    before = set(O)
    bpy.ops.wm.obj_import(filepath=os.path.join(rpath(d), "tex", "textured_mesh.obj"))
    ob = [o for o in O if o not in before][0]; ob.name = name
    m = bpy.data.materials.new(f"{name}_PBR"); m.use_nodes = True; N = m.node_tree.nodes; L = m.node_tree.links
    b = next(n for n in N if n.type == 'BSDF_PRINCIPLED')
    def tex(fn, cs):
        t = N.new('ShaderNodeTexImage'); t.image = bpy.data.images.load(os.path.join(rpath(d), "tex", fn), check_existing=True)
        t.image.colorspace_settings.name = cs; return t
    a = tex("textured_mesh.jpg", 'sRGB'); a.name = "T_albedo"
    hs = N.new('ShaderNodeHueSaturation'); hs.name = "Tone"
    L.new(a.outputs['Color'], hs.inputs['Color']); L.new(hs.outputs['Color'], b.inputs['Base Color'])
    r = tex("textured_mesh_roughness.jpg", 'Non-Color'); mr = N.new('ShaderNodeMapRange')
    mr.inputs['To Min'].default_value, mr.inputs['To Max'].default_value = rough
    L.new(r.outputs['Color'], mr.inputs['Value']); L.new(mr.outputs['Result'], b.inputs['Roughness'])
    ob.data.materials.clear(); ob.data.materials.append(m)
    for p in ob.data.polygons: p.use_smooth = True
    mn, mx = bbox_world(ob); s = height / (mx.z - mn.z)
    # 世界座標で正規化して焼き込む（M⁻¹…M にすると取り込み時の回転が二重にかかる）
    ob.data.transform(Matrix.Diagonal((s, s, s, 1)) @ Matrix.Translation((-(mn.x + mx.x) / 2, -(mn.y + mx.y) / 2, -mn.z)) @ ob.matrix_world)
    ob.matrix_world = Matrix.Identity(4)
    return ob

def tone(ob, t):
    if not t or ob.type != 'MESH': return
    for m in ob.data.materials:
        hs = next((n for n in m.node_tree.nodes if n.type == 'HUE_SAT'), None) if m and m.use_nodes else None
        if hs: hs.inputs['Hue'].default_value, hs.inputs['Saturation'].default_value, hs.inputs['Value'].default_value = t

placed, protos, fps = [], [], []
for e in PLAN.get("parts", []):
    name = e["name"]; src = e.get("source", "ai")
    if src == "ai":
        ob = load_ai(name, e["dir"], 1.0 if e.get("proto") else e.get("height", 2.0), tuple(e.get("rough", (0.4, 0.9))))
        if e.get("squash"): ob.data.transform(Matrix.Diagonal((*e["squash"], 1)))
    elif src == "copy":
        ob = O[e["copy_of"]].copy(); ob.name = name
    else:
        if O.get(name): bpy.data.objects.remove(O[name], do_unlink=True)
        ob = BUILDERS[e["type"]](name, e.get("params", {}), e)
    tone(ob, e.get("tone"))
    if e.get("proto"):
        pc = bpy.data.collections.get(f"P_{name}") or bpy.data.collections.new(f"P_{name}")   # シーン外のコレクション
        for c in list(ob.users_collection): c.objects.unlink(ob)
        pc.objects.link(ob); protos.append(name); continue
    for c in list(ob.users_collection): c.objects.unlink(ob)
    col.objects.link(ob)
    for x in e.get("_extra", []):
        for c in list(x.users_collection): c.objects.unlink(x)
        col.objects.link(x)
    if src == "blender" and e["type"] in WORLD_SPACE:
        placed.append(name)
    elif "pos" in e:
        p = e["pos"]; z = p[2] if len(p) > 2 else ground(p[0], p[1]) - e.get("sink", 0.05) + e.get("lift", 0.0)
        ob.location = (p[0], p[1], z); ob.rotation_euler = (0, 0, math.radians(e.get("yaw", 0)))
        placed.append(name)
    bpy.context.view_layer.update()
    if src == "blender" and e["type"] in WORLD_SPACE:          # 道・柵・橋: 点列に沿って避ける
        pts = e["params"].get("points") or [e["params"].get("a"), e["params"].get("b")] if e["type"] != "rocks" else []
        for a, b in zip(pts[:-1], pts[1:]):
            n = max(1, int(math.dist(a, b) / 2))
            for i in range(n + 1): fps.append([a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n, 2.0])
    elif ob.type == 'MESH':
        mn, mx = bbox_world(ob)
        fps.append([(mn.x + mx.x) / 2, (mn.y + mx.y) / 2, max(mx.x - mn.x, mx.y - mn.y) / 2])
SC["footprints"] = fps                      # 森の散布で避ける（建物の周り）
SC["protos"] = protos
RESULT = f"placed {placed}, protos {protos}"
