# AI で作るパーツ（建物・小物・木）の画像プロンプト

Playground v2.5（CLIP 77 トークン）→ Hunyuan3D-2.1。1 パーツ = 1 物体。地面・背景・人物を入れない。

## テンプレート
```
stylized <物> 3D render, game asset, <視点>, <形・色の特徴 3〜5 個>, smooth clean surfaces, isolated object, pure white background
```
- 視点: 建物は `three-quarter front view`（奥行きが出る）、門・塔・左右対称のものは `front view, symmetrical`、木は `whole tree with trunk`
- 木・植物: `painted toy style, smooth clumps`（葉の一枚一枚は 3D で崩れるので塊にする）
- ネガティブ（共通）:
```
multiple objects, cropped, cut off, ground, grass, landscape, background scenery, people, animals, text, watermark, blurry, shadow, flat 2d illustration
```

## 2026-10-04 に使ったもの（そのまま使える）
| パーツ | プロンプトの要点 | 採用 | 結果 |
|---|---|---|---|
| 神社の本殿 | single wooden hall with curved dark tiled roof, vermilion red pillars, white walls, short stone steps, golden ornaments | 4 枚中 s11（正面寄り） | 良好 |
| 鳥居 | bright vermilion red pillars, black top beam, standing alone, front view symmetrical | s11 | **奥行き 7m の二重鳥居状** → `squash [1,0.6,1]` で圧縮 |
| 石灯籠 | grey carved stone, single object | s11 | 良好 |
| 紅葉の木 | round dense canopy of autumn orange and red leaves | s11 | 良好（根元の落ち葉も付く） |
| 杉 → 松 | tall conical dense dark green canopy | s25 | 盆栽風の松になった（和風なので採用） |

## 選定のコツ
- 背景が灰色/暗くても背景除去（birefnet-general）で抜ける。床の影・台座が付いているものは避ける
- 門・鳥居・アーチなど「穴の空いた物」は奥行きが過大になりがち → 配置後に bbox を確認して `squash`
- 4 枚（seed 3,11,25,48）で十分なことが多い。条件を満たさなければプロンプトを直して再生成

## Blender で作る or AI で作る（判断表）
| Blender（sc_builders） | AI（Colab → Hunyuan3D） |
|---|---|
| 家・小屋（house）、道・石畳（stone_path）、橋（bridge）、柵（fence）、岩（rocks）、台・広場（platform）、明かり（light）、地形・湖・空 | 神社・寺・城・塔・洋館など装飾の多い建物、像・噴水、特徴のある木・花、乗り物、家具・小物で形が凝ったもの、キャラクター |
| 形が箱・板・円柱の組み合わせで言い表せるもの | 曲線・彫刻・有機的な形、「それっぽさ」が細部に宿るもの |
