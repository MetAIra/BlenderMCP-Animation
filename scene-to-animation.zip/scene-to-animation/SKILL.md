---
name: scene-to-animation
description: 風景・建物・キャラクターを組み合わせた 3D アニメーション（動画）を作る。地形・湖・空・家・道・橋などは Blender で直接作り、神社・城・像など複雑な建物や木は Google Colab MCP（Playground v2.5 → Hunyuan3D-2.1）で生成して Blender に取り込み、キャラクターに経路（飛ぶ・歩く・跳ねる）とカメラワークを付けて動画にする。ユーザーが「○○の感じでアニメーションを作って」「○○な風景で□□が△△するアニメーション」「風景/建物を作って動かして」などと頼んだときに使う。キャラクター単体のモデル作成は prompt-to-animated-3d、画像からは image-to-rigged-3d。
---

# 風景・建物 × キャラクターの 3D アニメーション

2026-10-04 に「夕焼けの森の神社からフクロウが飛び立ち湖を一周する」（`scenes/ShrineOwl/`）を作った手順を汎用化したもの。
**シーン全体を 1 つの `plan.json` に書き、`build_scene.py` で一括構築する。** 直したいときは plan を直して該当ステップだけ再構築する。

- `SKILL` = `.claude/skills/scene-to-animation`、`ROOT` = `G:\マイドライブ\003_Blender\blender-googlecolab`
- 関連スキル: キャラ作成 `prompt-to-animated-3d`（`P2A`）、Colab 側スクリプト・共通の作法 `image-to-rigged-3d`（`I2R`）。**I2R の「共通の作法」（Drive 同期待ち・Colab のバックグラウンド実行・Blender 実行の型）を守る。**
- 完成例の plan: `examples/shrine_owl_plan.json`（AI パーツ＋森＋飛行）、`examples/night_village_plan.json`（Blender 製の建物だけ＋夜＋歩き）

## 全体像（目安: AI パーツありで 60〜90 分、Blender 製だけなら 20〜30 分）

| Phase | 内容 | 場所 |
|---|---|---|
| 0 | 依頼を「絵コンテ」に分解（舞台・時間帯・建物・物語のビート・カット） | — |
| 1 | 各要素を Blender 製 / AI 製に振り分け（`prompts_parts.md` の判断表） | — |
| 2 | AI パーツ: 画像 4 枚/パーツ → 選ぶ → 背景除去 → 形状(1 シード) → テクスチャ（まとめてバックグラウンド） | Colab |
| 3 | キャラクター: 既存の `*_rigged.blend` を使う。無ければ P2A で作る（リグまで。アニメは不要） | Colab/Blender |
| 4 | `scenes/<Name>/plan.json` を書く → `build_scene`（terrain → sky → parts → scatter → characters → camera）| Blender |
| 5 | 確認フレーム → plan を直して部分再構築（数回）→ 動画 | Blender |
| 6 | 保存・README・報告 | — |

## Phase 0: 絵コンテ
依頼「○○の感じで」から次を決めて、短く提示してから作り始める（質問で止めない。迷う所は妥当な案で進め、報告で触れる）。
1. **舞台**: 地形（湖/平地/山）、時間帯（`sunset` / `dawn` / `noon` / `night`）、季節（地面 `palette`: grass/autumn/snow/desert、木の種類）
2. **建物・小物**: 主役の建物 1〜2 個＋脇役（灯籠・柵・道・橋…）。配置図（x,y）をざっくり。正面 -Y が基準、カメラ/主役が見る方向に向ける
3. **物語のビート**（キャラの経路）: 例「灯籠で佇む(1-80) → 鳥居をくぐる(112) → 湖を一周(140-400) → 鳥居に着地(465) → 夕日を見る」
4. **カット**: 3〜5 ショット。導入（アップ）→ 動き（固定 or 追従）→ 見せ場 → 締め（寄り）
5. 長さ: 15〜20 秒（450〜600f / 30fps）が目安

## Phase 2: AI パーツ（Colab）
- 準備は P2A Phase 1 と同じ（`install_hy.sh`、diffusers、`preprocess.py` を `birefnet-general` に）。既にランタイムがあれば再利用。
- プロンプト: `prompts_parts.md`。全パーツの画像生成を 1 本のチェーンで（`P2A/scripts/colab/t2i.py`）:
  `(python t2i.py {D}/t2i/<part> 3,11,25,48 p_<part>.txt neg.txt && ... ) > log 2>&1`（**括弧で囲む**）
- シートで選ぶ → 前処理・形状・テクスチャも 1 本のチェーンで: preprocess 全部 → gen_shape 全部（`42 512`）→ gen_tex 全部。面数の目安: 主役の建物 150k、門・小物 50〜60k、木（インスタンスで大量に置く）60k。
  出力は Drive `assets/parts/<part>/tex/textured_mesh*`（パーツは他のシーンでも使えるよう assets にまとめる。t2i の画像は `scenes/<Name>/work/t2i/<part>/`）。5 パーツで約 30 分（背景除去は 1 回ごとにモデルを読むので 1 分前後かかる）。
- 待つ間に Blender 側（地形・空・Blender 製の建物・カメラ）を先に組んで仮確認しておく。

## Phase 4: plan.json（スキーマは各スクリプト冒頭のコメントが正）
```jsonc
{
  "name": "X", "frames": 520, "fps": 30,
  "terrain": {"lake": {"center": [0,22], "radius": 18}, "mountains": {"height": 20}, "clearings": [{"center": [0,-10], "radius": [9,11]}], "palette": "grass"},
  "sky": {"preset": "sunset", "sun_elevation": 4, "sun_azimuth": 90},      // 方位: +X=0, +Y=90。夕日は湖の向こうに
  "parts": [
    {"name": "shrine", "source": "ai", "dir": "assets/parts/shrine", "height": 6.5, "pos": [0,-17], "yaw": 180},
    {"name": "house1", "source": "blender", "type": "house", "params": {"w": 6, "d": 5, "lit": true}, "pos": [8,-5], "yaw": 200},
    {"name": "path", "source": "blender", "type": "stone_path", "params": {"points": [[0,-14],[0,-3]]}},
    {"name": "lantern.R", "source": "copy", "copy_of": "lantern.L", "pos": [-2.6,-10.5], "yaw": 180},
    {"name": "maple", "source": "ai", "dir": "assets/parts/maple", "proto": true, "tone": [0.5,0.9,0.85]}
  ],
  "keep_clear": [{"rect": [-9,-24,9,6]}],                                   // 木を置かない場所（参道など）
  "scatter": [{"protos": {"maple": 0.3, "pine": 0.7}, "count": 350, "area": {"center": [0,8], "r": [12,107]}, "heights": {"maple": [5.5,8.5]}}],
  "characters": [{"blend": "characters/Owl/Owl_rigged.blend", "mesh": "Owl", "armature": "Owl_Armature", "rig": "winged", "height": 0.55,
                  "path": [{"f": 1, "pos": "lantern.L:top", "mode": "perch", "face": "sun"}, {"f": 80, "mode": "fly"}, ...]}],
  "shots": [{"type": "static", "f": [1,95], "pos": "lantern.L:top+[0.9,2.7,0.15]", "look": "lantern.L:top", "lens": 30}, ...],
  "render": {"fill_energy": 0.25, "bloom": 0.35, "exposure": 0}
}
```
- **位置の書き方（spec）**: `[x,y]`（地面に乗る）/ `[x,y,z]` / `"名前"` / `"名前:top"`（上面。止まり木・着地点）/ `"名前:center"`（くぐる点）/ `"名前:front"` / `"char"`（キャラ）/ `"sun"`（向き）＋ `"+[dx,dy,dz]"`
- **Blender 製の建物**（`sc_builders.py`）: `house`（切妻の家。`lit: true` で窓が光る）、`stone_path`、`bridge`（太鼓橋）、`fence`、`rocks`、`platform`、`light`（点光源＋光る球。夜の灯り）。
- **キャラの mode**: `perch`/`idle`（静止。`face` で向き）、`fly`、`glide`、`walk`、`run`、`hop`。静止→fly で踏み切り、fly→perch で着地の動きが自動で入る。湖の周回は `circle`。
  リグ種別ごとの動き: winged＝羽ばたき/よちよち歩き、quadruped＝対角歩様（walk/run）・しっぽ、hopper＝スクワッシュ＆ストレッチ。
- **カメラ**: `static`（look に `"char"` で首振り追従）、`dolly`（寄り/引き）、`chase`（後方追従）、`orbit`（周回）。ショットの境目は自動でカット。

## Phase 4〜5: 構築と確認
```python
SKILL = r"G:\マイドライブ\003_Blender\blender-googlecolab\.claude\skills\scene-to-animation"
ROOT = r"G:\マイドライブ\003_Blender\blender-googlecolab"
g = {"SKILL": SKILL, "ROOT": ROOT, "PARAMS": {"plan": "scenes/X/plan.json", "save": "scenes/X/X.blend",
     "render": {"mode": "frames", "out_dir": r"<scratchpad>\x1"}}}       # frames 省略 = 各ショットの頭・中・終わり
exec(open(SKILL + r"\scripts\blender\build_scene.py", encoding="utf-8").read(), g); raise Exception(g["RESULT"])
```
- **新しいシーンは先に `bpy.ops.wm.read_homefile(use_empty=True)` を別の呼び出しで**（同じ呼び出し内だとコンテキストが壊れて obj_import が失敗する）。
- 部分再構築: `"steps": ["characters", "camera"]`（経路・カメラだけ直す）、`["camera"]`、`["scatter"]` など。parts を作り直すと scatter/characters も再実行が必要。
- 確認フレームをシート化（I2R `local/make_sheet.py`）して見る。**チェック**:
  - パーツの大きさ・めり込み（RESULT の top 高さが想定どおりか。違えば `height`/`squash`）
  - カメラが建物を突き抜けていないか（chase は鳥居・門・木で起きやすい → その区間は static/dolly）
  - キャラが隠れていないか（着地点より低いカメラだと梁に隠れる → カメラを上端より上に）
  - 夕方/夜らしさ（木の `tone` で彩度・明るさを落とす、`fill_energy`）
- OK なら `save` 付きで保存し、**動画はバックグラウンドの Blender で出す**（MCP 経由の長時間レンダーは接続が切れ、Blender の再起動が必要になったため）:
  ```powershell
  $sk = "G:\マイドライブ\003_Blender\blender-googlecolab\.claude\skills\scene-to-animation"
  & "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" -b "<ROOT>\scenes\<Name>\<Name>.blend" --python "$sk\scripts\blender\bg_render.py" -- "<plan.json>" "scenes\<Name>\renders" "<Name>_" *> "<scratchpad>\bg_render.log"
  ```
  PowerShell の `run_in_background` で起動 → 完了通知を待つ（450f で約 5 分）。ログ末尾の `unregister_class ... RuntimeError` は終了時のアドオン解除の警告で無害。`BG_RENDER_DONE` が出ていれば成功。
- 動画は `cv2.VideoCapture` で数フレーム抜いて確認。

## Phase 6: 仕上げ
- `scenes/<Name>/README.md`: パーツ表（画像・面数・配置）、plan の要点、気づき。
- 報告: 動画・blend のパス、カット表（フレーム範囲と内容）、Blender 製 / AI 製の内訳、苦労した点、弱点（逆光でキャラが暗い等）と改善案。Colab の切断を促す。

## 検証状況（2026-10-04）
- `examples/shrine_owl_plan.json`: 元の手作業版（ShrineOwl.blend）と同等に再現。perch→fly の踏み切り、circle、fly→perch の着地、4 カット OK
- `examples/night_village_plan.json`（`scenes/NightVillage/`）: Blender 製の家×3・石畳・太鼓橋・柵・岩・街灯（支柱付き）・夜空・walk→fly→circle→屋根に着地、orbit/chase/dolly OK
- 夜のコツ: `sun_energy` 0.3 前後、`exposure` -0.2〜0、窓は `lit: true`、道沿いに `light`（`lift` 1.3）を置く。明かりが無いと真っ暗になる
- 着地の締めカットは、カメラを着地点（`:top`）より高く始める（低いと梁や屋根でキャラが隠れる）

## 既知の落とし穴（2026-10-04）
- OBJ を正規化する変換は `data.transform(S @ T @ matrix_world)` → `matrix_world = I`（`M⁻¹…M` だと取り込み時の回転が二重にかかり高さが狂う。sc_parts 対応済み）
- 散布の原型を `hide_render` にするとインスタンスも消える → 原型はシーン外のコレクションに置く（sc_parts 対応済み）
- EEVEE でワールドにボリューム（霞）を入れると全フレーム真っ黒 → 使わない
- 物理スカイ（Sky Texture）は低い太陽で白っぽい → 手作りグラデーション（sc_sky）
- 生成した鳥居は奥行き 7m（二重）だった → `squash`。着地点は `:top`（レイキャストで最も高い面）
- 追従カメラが鳥居を突き抜けた → くぐる場面は湖側からの固定カメラにしたら見栄えも良くなった
